Eagle-Libraries
===============

Eagle Stuff I'm working on


NEW
===============
1. **DRV8833**									:: 2A DUAL H-BRIDGE MOTOR DRIVER from Texas Instruments
2. **TCRT500**									:: Reflective Optical Sensor with Transistor Output from Vishay
